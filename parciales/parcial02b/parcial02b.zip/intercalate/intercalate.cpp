#include "intercalate.h"

int*
intercalate(const int arr1[],
	    const int arr2[],
	    const int nbr,
	    const int fact) {

  throw "No implemented yet";
}
