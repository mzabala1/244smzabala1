#pragma once

int* intercalate(const int arr1[],
		 const int arr2[],
		 const int nbr,
		 const int fact);

		
