#include "player.h"

Player::Player(unsigned short nLifes,
               unsigned short nBullets,
               unsigned short armorLevel,
               unsigned short shotFactor) :
  nLifes(nLifes),
  nBullets(nBullets),
  armorLevel(armorLevel),
  shotFactor(shotFactor)
{}

