#include "parityTest.h"

Parity parityTest(const char word[], int& nEven, int &nOdd) {

  throw "No implemented yet";
}
