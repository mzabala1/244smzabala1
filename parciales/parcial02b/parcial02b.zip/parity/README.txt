Para compilar:

$ make

Para ejecutar el programa checkParity tiene como entrada el numero
de cadenas que se van a revisar y luego un numero igual de cadenas.

En el siguiente ejemplo el valor > indica la salida pero en realidad
no apare. a es par b es impar.

$ ./checkParity 
3
a
> 2 1 0
b
> 1 0 1
ab
> 0 1 1

