#pragma once

bool isEvenParity(char c);
bool isOddParity(char c);
